import React ,{Component} from 'react';

class Hello extends  Component {
  constructor() {
    super();

  }

  render() {
    return (
        <h1> Hello Danny</h1>
    )
  }

//   componentDidMount() {
//     this.setState({ someKey: 'otherValue' });
//   }
}

export default Hello;
