import org.apache.spark.api.java.JavaRDD

def sendMessageByRDD(broker :String, protocol :String, rdd :JavaRDD[Any], topic :String) = {
    val props = new Properties() 
    
    props.put("security.protocol", protocol)
    props.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer")
    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("bootstrap.servers", broker)
    ???
}