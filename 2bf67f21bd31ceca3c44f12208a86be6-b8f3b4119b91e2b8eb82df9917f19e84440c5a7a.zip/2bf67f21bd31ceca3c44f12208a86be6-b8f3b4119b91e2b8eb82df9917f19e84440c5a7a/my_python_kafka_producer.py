from pyspark.serializers import PickleSerializer, AutoBatchedSerializer


reserialized_rdd = rdd._reserialize(AutoBatchedSerializer(PickleSerializer()))
rdd_java = rdd.ctx._jvm.SerDe.pythonToJava(rdd._jrdd, True)

_jvm = sc._jvm
_jvm.myclass.apps.mine\
                 .pyKafka\
                 .sendMessageByRDD("host:6667", 
                                   "SASL_PLAINTEXT", 
                                   rdd_java, 
                                   'my_topic')
                                     

